<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div style="height:50px">
	<div class="aioseo-loading-spinner dark" style="top:calc( 50% - 17px);left:calc( 50% - 17px);">
		<div class="double-bounce1"></div>
		<div class="double-bounce2"></div>
	</div>
</div>